﻿using System;
using UnityEngine;

namespace FMODUnity
{
    public class EventRefAttribute : PropertyAttribute
    {
    }
}
