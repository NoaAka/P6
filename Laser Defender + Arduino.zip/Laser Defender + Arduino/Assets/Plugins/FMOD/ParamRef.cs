﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FMODUnity
{
    [Serializable]
    public class ParamRef
    {
        public string Name;
        public float Value;
    }
}
